﻿=== Automatic Updates ===
Contributors: fahadmahmood
Tags: Alphabetic Pagination, Authors Posts Widget, Chameleon, Easy Upload Files During Checkout, Endless Posts Navigation, Gulri Slider, Injection Guard, jQuery Post Splitter, Keep Backup Daily, Rss Feed Widget, Woo Coming Soon, Woo Installments, Woo Order Splitter, Woocommerce Discounts Plus, Wp Datepicker, Wp Docs, Wp Easy Sharing, Wp E Commerce Whish List, Wp Header Images, Wp Mechanic, Wp Quick Shop, Wp Responsive Tabs, Wp Secure Content, Wp Sort Order, Wp Speedup

Requires at least: 3.0
Tested up to: 6.5
Stable tag: 1.1.6
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Android Bubbles Automatic Updates plugin is a utility plugin for all premium and free versions of WordPress plugins developed by WordPress Mechanic Fahad Mahmood from Lahore Pakistan.

== Description ==

* Author: [Fahad Mahmood](https://www.androidbubbles.com/contact)
* Project URI: <https://androidbubbles.wordpress.com/2018/04/11/automatic-updates>
* License: GPL 3. See License below for copyright jots and titles.

Important!
Visit my blog and suggest good features which you wana see in this plugin.

== Installation ==

To use Automatic Updates, you will need:
* 	an installed and configured copy of [WordPress][] (version 3.0 or later).
*	FTP, SFTP or shell access to your web host

== Screenshots ==

= New Installations =

Method-A:

1. Go to your wordpress admin "yoursite.com/wp-admin"
2. Login and then access "yoursite.com/wp-admin/plugin-install.php?tab=upload
3. Upload and activate this plugin
4. Now go to admin menu -> settings -> Automatic Updates
5- Choose your layout and case settings
6- Make sure that its working fine for you and don't forget to give your feedback

Method-B:
1.	Download the Automatic Updates installation package and extract the files on your computer. 
2.	Create a new directory named `ab-automatic-updates` in the `wp-content/plugins`	directory of your WordPress installation. Use an FTP or SFTP client to upload the contents of your ab-automatic-updates archive to the new directory that you just created on your web host.
3.	Log in to the WordPress Dashboard and activate the Automatic Updates plugin.
4.	Once the plugin is activated, a new **Automatic Updates** sub-menu will appear in your Wordpress admin -> settings menu.




== Changelog ==



== Upgrade Notice ==



= Upgrades =
To *upgrade* an existing installation of Automatic Updates to the most recent release:
1.	Download the Automatic Updates installation package and extract the files on your computer.
2.	Upload the new PHP files to `wp-content/plugins/ab-automatic-updates`, overwriting any existing Automatic Updates files that are there.
3.	Log in to your WordPress administrative interface immediately in order to see whether there are any further tasks that you need to perform to complete the upgrade.
4.	Enjoy your newer and hotter installation of Automatic Updates 

== License ==

Automatic Updates is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or any later version. Automatic Updates is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with Automatic Updates. If not, see http://www.gnu.org/licenses/gpl-2.0.html.