// JavaScript Document

jQuery(document).ready(function($){

	$('.ab-pro-link').on('click', function(event){

		event.preventDefault();

		$('.ab-pro-panel').show();

	});

	$('input[type="button"][name="c"]').on('click', function(){

		$('.ab-pro-panel').hide();

	});

	$('#ab-pro-plugin').on('change', function(){

		if($(this).val()==''){

			$('.ab-pro-panel input[name="s"]').prop('disabled', true);

		}else{

			$('.ab-pro-panel input[name="s"]').prop('disabled', false);

		}

	});	

	$('#ab-pro-plugin').change();

	$('.ab-stored-credentials li a.loadp').on('click', function(){

		var obj = $(this).parent();

		//console.log(obj.data('e'));

		$('input[name="e"]').val(obj.data('e'));

		$('input[name="p"]').val(obj.data('e'));

		$('input[name="i"]').val(obj.data('i'));

		$('select[name="a"]').val(obj.data('a'));

	});
	
	$('form#ab-pro-form').on('click', 'input[name="s"]', function(event){
		event.preventDefault();
		var obj_btn = $(this);
		obj_btn.prop('disabled', true);
		$('.ab-response').html(ab_au_obj.loading_img);
		$.post(ajaxurl, {
							action: 'ab_activate',
							"e":$('input[name="e"]').val(),
							"p":$('input[name="p"]').val(),
							"i":$('input[name="i"]').val(),
							"a":$('select[name="a"]').val(),
							"rm":$('input[name="rm"]').val(),
							"ab_pro_action_field":$('input[name="ab_pro_action_field"]').val()
						}, function(resp) {
							
			$('.ab-response-msg').html(resp);
			obj_btn.prop('disabled', false);
			setTimeout(function(){ $('.ab-response-msg').html('');  }, 20000*3);
			$('.ab-response').html('');
			
		});
	});
	
	$('.ab_au_settings_div h2').on('click', function(){
		
		var obj_heading = $(this);
		var permitted = obj_heading.data('permission');
		if(permitted=='allowed'){
			var ask = confirm(ab_au_obj.permission_confirmation);
			if(ask){
				
			}else{
				return false;
			}
		}else{
		}
		obj_heading.toggleClass('allowed');
		$.post(ajaxurl, {action: 'ab_permission',"permission":permitted,"ab_pro_action_field":$('input[name="ab_pro_action_field"]').val()}, function(response) {
			//console.log(obj_heading);
			//console.log(response);
			obj_heading.attr({'data-permission': permitted?'':'allowed'});
			//document.location.reload();
		});
	});

	$('.ab-stored-credentials li a.red').on('click', function(){

		var ask = confirm(ab_au_obj.delete_confirmation);

		if(ask){

			var obj = $(this).parent();

			$.post(ajaxurl, {action: 'ab_delete',"i":obj.data('i')}, function(response) {

				response = jQuery.parseJSON(response);	

																			

				if(response.msg){

					obj.fadeOut(1000);					

					setTimeout(function(){ obj.remove(); }, 3000);

				}																

				

			});

		}

	});

});