<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly 
/*
Plugin Name: Automatic Updates
Plugin URI: https://androidbubbles.wordpress.com/2018/04/11/automatic-updates
Description: Automatic Updates is a great plugin to update all free and premium plugins developed by WordPress Mechanic Fahad Mahmood from Lahore Pakistan.
Version: 1.1.6
Author: Fahad Mahmood 
Text Domain: ab-automatic-updates
Author URI: https://www.androidbubbles.com
License: GPL2

Automatic Updates is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 2 of the License, or any later version. Automatic Updates is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with Automatic Updates. If not, see http://www.gnu.org/licenses/gpl-2.0.html.
*/ 

	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	global $ab_au_data, $ab_au_url;
	$ab_au_url = plugin_dir_url( __FILE__ );
	$ab_au_data = get_plugin_data(__FILE__);
	include('inc/functions.php');
	register_activation_hook(__FILE__, 'ab_au_start');
	register_deactivation_hook(__FILE__, 'ab_au_end' );
	add_action( 'admin_enqueue_scripts', 'register_ab_au_scripts' );
	add_action( 'wp_enqueue_scripts', 'register_ab_au_scripts' );

	if(is_admin()){
		
		add_action( 'wp_ajax_ab_permission', 'ab_permission' );
		add_action( 'wp_ajax_ab_delete', 'ab_delete' );
		add_action( 'wp_ajax_ab_activate', 'ab_activate' );
		add_action( 'admin_menu', 'ab_au_menu' );	
		$plugin = plugin_basename(__FILE__); 
		add_filter("plugin_action_links_$plugin", 'ab_au_plugin_links' );
		add_action( 'admin_enqueue_scripts', 'ab_au_admin_style', 99 );		
	}else{

		

	}