<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



$plugins_list = array();

$all_plugins = get_plugins();

if(!empty($all_plugins)){

	//pree($all_plugins);//exit;

	foreach($all_plugins as $plugins){
		
		//pree(in_array('Fahad Mahmood', $plugins) || in_array('fahadmahmood', $plugins));
		$belongs_to_fahad = (
				(in_array('Fahad Mahmood', $plugins) || in_array('fahadmahmood', $plugins))  
			
			||
				
				(strpos($plugins['Author'], 'Fahad Mahmood')!==false)
		);
		
		if($belongs_to_fahad && !in_array('Automatic Updates', $plugins)){

			$uri = basename($plugins['PluginURI']);
			
			//pree($uri);

			$title = $plugins['Title'];
			//pree($plugins);

			$plugins_list[$uri] = $title;
			
			

		}

	}

	//pree($plugins_list);

}


$ab_updates = get_option('ab_updates_permission', '');

?>



<div class="wrap ab_au_settings_div">



        



<div class="icon32" id="icon-options-general"><br></div><h2 title="<?php echo $ab_updates=='allowed'?__('You have permitted this 3rd party plugin to get auto updates. Click here to TURN it OFF.','ab-automatic-updates'):__('Click here to turn ON/OFF auto updates for this 3rd party plugin Automatic Updates','ab-automatic-updates'); ?>" data-permission="<?php echo $ab_updates?'':'allowed'; ?>" class="<?php echo $ab_updates?'allowed':''; ?>"><?php echo $ab_au_data['Name']; ?> <?php echo '('.$ab_au_data['Version'].')'; ?> - <?php _e('Settings','ab-automatic-updates'); ?> 
<span class="dashicons dashicons-yes"></span>
<span class="dashicons dashicons-shield"></span>
</h2> 



<div class="ab-pro-panel">

<?php

	$e = $p = $i = $rm = ''; $a = '|';

	$ab_pro_token = get_option('ab_pro_token', array());	

	$ab_pro_token = (is_array($ab_pro_token)?$ab_pro_token:array());

	$ab_pro_token = ab_repair_tokens($ab_pro_token);	


	if(!empty($ab_pro_token) && count($ab_pro_token)>0){
	
		$ab_pro_token_first = current($ab_pro_token);
	
		list($e, $p, $i, $a) = $ab_pro_token_first;
	
		
	
	}
		


?>
<?php //pree($plugins_list); ?>
<?php
	

?>
<div style="clear:both;">
<div class="ab-response-msg"></div>
<strong><?php _e('Please enter your email address and password which you received after purchase.'); ?></strong>
</div>

<form id="ab-pro-form" name="ab-pro-form" method="post">

<?php wp_nonce_field( 'ab_pro_action', 'ab_pro_action_field' ); ?>



	<table cellpadding="0" cellspacing="0" border="0">

    	<tbody>

        	<tr><td colspan="2"></td></tr>

        	<tr><td><label for="ab-pro-login"><?php _e('Email'); ?></label>:</td><td><input id="ab-pro-login" type="email" name="e" placeholder="<?php _e('Email Address'); ?>" value="<?php echo $e; ?>" /></td></tr>

            <tr><td><label for="ab-pro-key"><?php _e('Password'); ?></label>:</td><td><input id="ab-pro-key" type="password" name="p" placeholder="<?php _e('Password'); ?>" value="<?php echo $p; ?>" /></td></tr>

            <tr><td><label for="ab-pro-invoice"><?php _e('Invoice ID'); ?></label>:</td><td><input id="ab-pro-invoice" type="text" name="i" placeholder="<?php _e('Receipt No./Invoice ID/Transaction ID or Sale ID'); ?>" value="<?php echo $i; ?>" /></td></tr>

            <tr><td><label for="ab-pro-plugin"><?php _e('Plugin'); ?></label>:</td><td>

            <?php if(!empty($plugins_list)): list($uri_first, $title_item) = explode('|', $a);// pree($uri_first); ?>

            <select name="a" id="ab-pro-plugin">

            <option value=""><?php _e('Select a Plugin'); ?></option>

            <?php foreach($plugins_list as $uri=>$title): ?>

            <option value="<?php echo $uri.'|'.$title; ?>" <?php selected($uri_first==$uri); ?>><?php echo $title; ?></option>

            <?php endforeach; ?>

            </select>

            <?php endif; ?>

            </td></tr>

            <tr><td>&nbsp;</td><td><input id="ab-pro-remember" type="checkbox" name="rm" value="yes" <?php checked( $rm=='yes' || $rm=='' ); ?> /><label for="ab-pro-remember"><?php _e('Remember these credentials?'); ?></label></td></tr>

            <tr><td colspan="2" style="height:10px;"></td></tr>

            <tr><td>&nbsp;</td><td><input type="button" name="s" class="button button-primary" disabled="disabled" value="<?php _e('Activate'); ?>" /></td></tr>

            

            <tr><td></td><td><a target="_blank" href="https://shop.androidbubbles.com/my-account/lost-password/"><?php _e('Forgot password?'); ?></a>&nbsp;|&nbsp;<a target="_blank" href="https://shop.androidbubbles.com/download"><?php _e('Manual download?'); ?></a></td></tr>

            <tr><td colspan="2" class="ab-response">
            



            
        
            
            </td></tr>

        </tbody>

    </table>

    

    <ul class="ab-stored-credentials">

    	<?php

			if(!empty($ab_pro_token)){

				

				//pree($ab_pro_token);

				

				$ab_pro_token = ab_repair_tokens($ab_pro_token);

				

				//pree($ab_pro_token);

				

				foreach($ab_pro_token as $ab_invoice=>$ab_row){

					list($e, $p, $i, $a) = $ab_row;

					

					list($uri_item, $title_item) = explode('|', $a);

		?>

        			<li data-e="<?php echo $e; ?>" data-i="<?php echo $i; ?>" data-a="<?php echo $a; ?>"><a class="loadp"><?php echo $title_item?$title_item:__('Premium Version'); ?> - <?php echo $ab_invoice; ?> - <?php echo $e; ?></a> - <a class="red"><?php _e('Delete'); ?></a></li>

        <?php

				}

			}

		?>

    	    

    </ul>

</form>

<div style="clear:both">
<?php _e('<strong>Disclaimer: '.'This form submission is well tested and secure but still please review that how does it work? </strong>'); ?>
<small>
            <ol>

            	<li><?php _e('It submits the required credentials to the plugin\'s author website https://shop.androidbubbles.com/ including your website address.'); ?></li>

                <li><?php _e('If login credentials are valid, you will receive a premium copy of the plugin.'); ?></li>

                <li><?php _e('That premium copy will be saved on your server in compressed format temporarily and after extraction it will be removed automatically.'); ?></li>

                <li><?php _e('In case you are not comfortable with this style so you may download the premium copy from direct download link above.'); ?></li>

            </ol>

            

            </small>
</div>            
<?php

	

?>

</div>