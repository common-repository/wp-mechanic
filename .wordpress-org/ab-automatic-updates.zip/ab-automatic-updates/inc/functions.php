<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly



	add_action('admin_head', 'ab_disable_updates');

	

	function ab_disable_updates(){		

		$all_plugins = get_plugins();

		//pree($all_plugins);

		//woocommerce-discounts-plus/index.php

		$premium_updates = array();
			

		$ab_pro_token = get_option('ab_pro_token', array());	

		$ab_pro_token = (is_array($ab_pro_token)?$ab_pro_token:array());

		$ab_pro_token = ab_repair_tokens($ab_pro_token);

		

		if(!empty($all_plugins)){

			foreach($all_plugins as $pindex => $plugins){

				$Author = $plugins['Author'];

				if($Author=='Fahad Mahmood'){

					foreach($ab_pro_token as $ab_invoice=>$ab_row){

						list($e, $p, $i, $a) = $ab_row;

						

						list($uri_item, $title_item) = explode('|', $a);

						

						if(in_array($title_item, $plugins)){

							//pree($title_item);

							//pree($pindex);

							//pree($plugins);

							$premium_updates[$pindex] = $plugins;

						}

					}

				}

			}

		}

		

		if(!empty($premium_updates)){

?>

<script type="text/javascript" language="javascript">

	jQuery(document).ready(function($){	

		if($('#update-plugins-table').length>0){

<?php			

		foreach($premium_updates as $pindex=>$plugins){

?>

		$('#update-plugins-table tbody tr td input[value="<?php echo $pindex; ?>"]').prop('disabled', true);

		$('#update-plugins-table tbody tr td input[value="<?php echo $pindex; ?>"]').parents().eq(1).find('p strong').append(' <span>(Premium Plugin)</span>');

		$('#update-plugins-table tbody tr td input[value="<?php echo $pindex; ?>"]').parents().eq(1).find('p').append('<a class="ab-updates-link" href="options-general.php?page=ab_au">Update Premium Plugin</a>');

		

<?php			

		}

?>

		}

	});

</script>

<?php			

		}

	}



	add_action('admin_init', 'ab_au_updates');

	

	function ab_au_updates(){

	

		global $ab_au_data;

		

		$last_checked = get_option('ab_automatic_updates', 'INIT');
		$ab_updates_permission = get_option('ab_updates_permission', '');

		

		$last_checked_diff = 0;

		//pree($last_checked);

		if(is_numeric($last_checked) && $ab_updates_permission=='allowed')

		$last_checked_diff = round(abs(time()-$last_checked)/(60 * 60 * 24));

		

		//pree($last_checked_diff);

		

		//pree($ab_au_data);
		
		

		

		if(($last_checked_diff>10 || $last_checked=='INIT')){

			$response = wp_remote_get( 'https://plugins.svn.wordpress.org/wp-mechanic/assets/ab-automatic-updates.txt' );

			if ( is_array( $response ) ) {

			  $header = $response['headers']; // array of http header lines

			  $latest = $response['body']; // use the content

			  $current = $ab_au_data['Version'];

			  //pree($latest);pree($current);

			  

			  

			  update_option('ab_automatic_updates', time());

			  if($current<$latest){

				//pree($current);pree($latest);

				$latest_copy = wp_remote_get( 'https://plugins.svn.wordpress.org/wp-mechanic/assets/ab-automatic-updates.zip' );

				if ( is_array( $latest_copy ) ) {

					$header = $latest_copy['headers']; // array of http header lines

					$archive = $latest_copy['body']; // use the content

					

								

					$uploads = wp_upload_dir();

					$basedir = $uploads['basedir'].'/';

					$plugins_dir = (dirname(plugin_dir_path( __DIR__ )));

									

					$fzip = $basedir.'ab-automatic-updates.zip';

					if(file_exists($fzip)){

						unlink($fzip);

					}

					//pree($fzip);

					$f = fopen($fzip, 'w');

					fwrite($f, $archive);

					fclose($f);

					

					

					//pree($plugins_dir);
					
					if(class_exists('ZipArchive')){

						$zip = new ZipArchive;
	
						$res = $zip->open($fzip);
	
						if ($res === TRUE) {				
	
							$zip->extractTo($plugins_dir);
	
							$zip->close();
	
							//echo "Done";
	
							unlink($fzip);
	
						}
						
					}

					

				}

			  }

			  

			}	

			

		}

	

	}


	function sanitize_ab_au_data( $input ) {
		if(is_array($input)){		
			$new_input = array();	
			foreach ( $input as $key => $val ) {
				$new_input[ $key ] = (is_array($val)?sanitize_ab_au_data($val):sanitize_text_field( $val ));
			}			
		}else{
			$new_input = sanitize_text_field($input);			
			if(stripos($new_input, '@') && is_email($new_input)){
				$new_input = sanitize_email($new_input);
			}
			if(stripos($new_input, 'http') || wp_http_validate_url($new_input)){
				$new_input = esc_url($new_input);
			}			
		}	
		return $new_input;
	}	


	if(!function_exists('pre')){
		function pre($data){
			if(isset($_GET['debug'])){
				pree($data);
			}
		}	 
	} 	

	if(!function_exists('pree')){
		function pree($data){
				echo '<pre class="red">';
				print_r($data);
				echo '</pre>';			
		}	 
	} 

	function ab_au_menu(){
		global $ab_au_data;
		add_options_page($ab_au_data['Name'], $ab_au_data['Name'], 'activate_plugins', 'ab_au', 'ab_au');
	}

	function ab_au(){ 
		if ( !current_user_can( 'administrator' ) )  {
			wp_die( __( 'You do not have sufficient permissions to access this page.', 'ab-automatic-updates' ) );
		}
		global $ab_au_data;
		include('ab_au_settings.php');	
	}	



	if(!function_exists('ab_au_start')){
		function ab_au_start(){	
		}	
	}



	if(!function_exists('ab_au_end')){
		function ab_au_end(){	

		}
	}	

	function ab_au_plugin_links($links) { 
		$settings_link = '<a href="options-general.php?page=ab_au">'.__('Settings', 'ab-automatic-updates').'</a>';
		array_unshift($links, $settings_link); 
		return $links; 
	}
	
	function register_ab_au_scripts() {
		
		global $ab_au_url;
		
		wp_register_style('ab-au-front', plugins_url('css/front-style.css', dirname(__FILE__)));
		wp_enqueue_style( 'ab-au-front' );
		if(!is_admin()){			
			//wp_enqueue_style('ab-au-mobile', plugins_url('css/mobile.css', dirname(__FILE__)), array(), date('Ymd'), 'all' );
		}else{
	
	
			$translation_array = array(
				'delete_confirmation' => __('Are you sure, you want to delete this entry?', 'ab-automatic-updates'),
				'loading_img' => '<img src="'.$ab_au_url.'images/loader.gif" />',
				'permission_confirmation' => __('Are you sure that you want to allow auto updates for this 3rd party plugin?','ab-automatic-updates')
			);
			
			
			//pree($translation_array);exit;
			
			wp_enqueue_script(
				'ab-au-scripts',
				plugins_url('js/scripts.js', dirname(__FILE__)),
				array('jquery')
			);
			
			wp_localize_script( 'ab-au-scripts', 'ab_au_obj', $translation_array );					
		}
	}

	function ab_au_admin_style() {
		wp_register_style('ab-au-admin', plugins_url('css/admin-style.css', dirname(__FILE__)));
		wp_enqueue_style( 'ab-au-admin' );
	}
	
	
	function ab_activate(){
		
		//pree($_POST);exit;
		//pree(wp_verify_nonce( $_POST['ab_pro_action_field'], 'ab_pro_action' ));exit;
		
		if(!empty($_POST) && isset( $_POST['ab_pro_action_field'] )){
				
			if(
	
					isset($_POST['e']) && trim($_POST['e'])!='' 
	
				&& 
	
					isset($_POST['p']) && trim($_POST['p'])!='' 
	
				&& 
	
					isset($_POST['i']) && trim($_POST['i'])!=''
	
				&& 
	
					isset($_POST['a']) && trim($_POST['a'])!=''				
	
				&&
	
					isset( $_POST['ab_pro_action_field'] )
	
				&&
	
					wp_verify_nonce( $_POST['ab_pro_action_field'], 'ab_pro_action' ) 
	
			){
	
					$em = trim($_POST['e']);
	
					$pa = trim($_POST['p']);
	
					$pl = trim($_POST['a']);
	
					$in = trim($_POST['i']);
	
					//pree($_POST);exit;
	
					$ab_pro_token = get_option('ab_pro_token', array());	
				
					$ab_pro_token = (is_array($ab_pro_token)?$ab_pro_token:array());
				
					$ab_pro_token = ab_repair_tokens($ab_pro_token);
				
					
				
					$e = $p = $i = $rm = ''; $a = '|';
				
					//pree($ab_pro_token);
				
					
				
					$uploads = wp_upload_dir();
				
					$basedir = $uploads['basedir'].'/';
				
					$plugins_dir = (dirname(plugin_dir_path( __DIR__ )));					
	
					
	
					if($_POST['p']==$_POST['e'] && array_key_exists($in, $ab_pro_token)){
	
						$ab_pro_token_load = $ab_pro_token[$in];
	
						list($e, $pa, $i, $a) = $ab_pro_token_load; //we're loading only password from database
	
					}
	
					//pree($e);pree($pa);pree($i);pree($a);exit;
	
					$response = wp_remote_post( 'https://shop.androidbubbles.com/?wp', array(
	
						'method' => 'POST',
	
						'timeout' => 45,
	
						'redirection' => 5,
	
						'httpversion' => '1.0',
	
						'blocking' => true,
	
						'headers' => array(),
	
						'body' => array( 'e' => $em, 'p' => $pa , 'a' => $pl, 'i' => $in, 'r' => home_url()),
	
						'cookies' => array()
	
						)
	
					);
	
					
	
					$a = explode('|', $_POST['a']);
	
					list($uri, $title) = $a;
	
					
	
					//pree($response);exit;
	
					if ( is_wp_error( $response ) ) {
	
					   $error_message = $response->get_error_message();
	
					   echo '<div class="alert alert-danger fade in alert-dismissible show"><strong>Sorry!</strong> '."Something went wrong: $error_message</div>";
	
					} else {
	
					   $body = $response['body'];
	
					   
	
					   $msg = '';
	
					   
	
					   if($body){
	
							$json = json_decode($body);
	
							$msg = isset($json->msg)?$json->msg:'';
	
					   }else{
	
							echo '<div class="alert alert-danger fade in alert-dismissible show"><strong>'.__('Sorry!').'</strong> '.__('Provided credentials are not correct or maybe not yet updated and synchronized on cloud.').' '.__('Please').' <a href="options-general.php?page=ab_au">'.__('try again.').'</a></div>';exit;
	
					   }
	
					   
	
						//pree($_POST);
	
						if($_POST['rm']=='yes'){
	
							//pree($ab_pro_token);						
	
							$ab_pro_token[$_POST['i']] = array($_POST['e'], $pa, $_POST['i'], $_POST['a']);						
	
							//pree($ab_pro_token);exit;
	
							update_option('ab_pro_token', $ab_pro_token);
	
						}else{
	
							//delete_option('ab_pro_token');				   
	
						}
	
					   
	
					   if($msg!=''){
						   /*
	
	?>
	
					<script type="text/javascript" language="javascript">
	
						alert('<?php echo $json->msg; ?>');
	
						setTimeout(function(){ window.location.reload(); }, 1000);
	
					</script>		
	
					
	
	<?php				*/
	
							echo '<div class="alert alert-danger fade in alert-dismissible show"><strong>Sorry!</strong> '.$json->msg.'</div>';exit;
	
					   }elseif($body!=''){
	
						   
	
	
	
							
	
							//pree($body->msg);
	
							
	
							$fzip = $basedir.'ab_pro.zip';
	
							if(file_exists($fzip)){
	
								unlink($fzip);
	
							}
	
							$f = fopen($fzip, 'w');
	
							fwrite($f, $body);
	
							fclose($f);
	
			
	
					   
	
					   
							if(class_exists('ZipArchive')){
								
								$zip = new ZipArchive;
		
								$res = $zip->open($fzip);
		
								if ($res === TRUE) {				
		
									$zip->extractTo($plugins_dir);
		
									$zip->close();
		
									//echo "Done";
		
									unlink($fzip);
									
									
									echo '<div class="alert alert-success fade in alert-dismissible show" style="margin-top:18px;"><strong>Success!</strong> '.__('Your purchased plugin has been activated with the premium version.').'</div>';
									
									/*
		
		?>
		
						<script type="text/javascript" language="javascript">
		
							alert('<?php echo __('Your purchased plugin has been activated with the premium version.'); ?>');
		
							setTimeout(function(){ window.location.reload(); }, 1000);
		
						</script>		
		
						
		
		<?php			*/
		
		
								exit;		
		
								} else {
		
									//echo "Failed";
									
		
								}
								
							}
		
	
	
					
	
					   }
	
				   
	
				   
	
			   }
	
			   
	
			}	
			
		}		
	}
	
	function ab_permission(){
		if(!empty($_POST) && isset( $_POST['ab_pro_action_field'] )){
				
			if(
	
					isset($_POST['permission'])
				&&	
	
					isset( $_POST['ab_pro_action_field'] )
	
				&&
	
					wp_verify_nonce( $_POST['ab_pro_action_field'], 'ab_pro_action' ) 
	
			){
				$permission = (in_array($_POST['permission'], array('', 'allowed'))?trim($_POST['permission']):'');
				update_option('ab_updates_permission', $permission);
				echo $permission?'allowed':'';
			}
			
		}
		
		exit;
	}

	function ab_delete(){

		

		if(!isset($_POST['i']))
		die();
		
		$return['msg'] = false;
		$return = array();	
		$ab_pro_token = get_option('ab_pro_token', array());
		$ab_pro_token = (is_array($ab_pro_token)?$ab_pro_token:array());	
		if(!empty($ab_pro_token) && array_key_exists($_POST['i'], $ab_pro_token)){
			unset($ab_pro_token[$_POST['i']]);
			update_option('ab_pro_token', $ab_pro_token);
			$return['msg'] = true;
		}
		echo json_encode($return);
		exit;		

	}
	
	function ab_repair_tokens($ab_pro_token){
		if(isset($ab_pro_token[0]) && !is_array($ab_pro_token[0]) && count($ab_pro_token)==4){
			$ab_pro_token_updated = array();
			$ab_pro_token_updated[$ab_pro_token[2]] = $ab_pro_token;
			$ab_pro_token = $ab_pro_token_updated;
		}		
		return $ab_pro_token;
	}
	
	
